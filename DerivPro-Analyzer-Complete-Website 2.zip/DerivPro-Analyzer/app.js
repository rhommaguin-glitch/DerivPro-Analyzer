/* DerivPro Analyzer - public market data only. No account auth and no trade actions. */
(() => {
  "use strict";
  const WS_URL = "wss://api.derivws.com/trading/v1/options/ws/public";
  const $ = (id) => document.getElementById(id);
  const state = { ws:null, markets:[], selected:null, ticks:[], candles:[], history:[], subscriptions:[], candleSeconds:60, lastSignalKey:"", reconnectTimer:null };
  const saved = (() => { try { return JSON.parse(localStorage.getItem("dpa-history") || "[]"); } catch { return []; } })();
  state.history = Array.isArray(saved) ? saved.slice(0,30) : [];
  $("year").textContent = new Date().getFullYear();

  function send(payload){ if(state.ws && state.ws.readyState===WebSocket.OPEN) state.ws.send(JSON.stringify(payload)); }
  function setConnection(text, ok=false){ $("connection-label").textContent=text; const dot=document.querySelector(".top-status .live-dot"); dot.style.background=ok?"#25d695":"#ffbd69"; }
  function connect(){
    try { state.ws = new WebSocket(WS_URL); } catch(e){setConnection("Connection unavailable");return;}
    state.ws.onopen=()=>{setConnection("Connected to Deriv public feed",true);send({active_symbols:"brief",req_id:1});};
    state.ws.onmessage=(event)=>{let msg;try{msg=JSON.parse(event.data);}catch{return;}
      if(msg.error){console.warn("Deriv API:",msg.error.message);return;}
      if(msg.msg_type==="active_symbols") handleSymbols(msg.active_symbols||[]);
      if(msg.msg_type==="history" && msg.history) handleHistory(msg);
      if(msg.msg_type==="tick" && msg.tick) handleTick(msg.tick);
    };
    state.ws.onerror=()=>setConnection("Feed connection issue");
    state.ws.onclose=()=>{setConnection("Reconnecting…");clearTimeout(state.reconnectTimer);state.reconnectTimer=setTimeout(connect,4000);};
  }
  function handleSymbols(items){
    // Synthetic indices are grouped under the synthetic_index market category in Deriv's symbol catalogue.
    state.markets=items.filter(x => {
      const type=String(x.market||"").toLowerCase()+" "+String(x.submarket||"").toLowerCase()+" "+String(x.underlying_symbol_type||"").toLowerCase();
      return type.includes("synthetic") || type.includes("derived");
    }).map(x=>({symbol:x.underlying_symbol,name:x.underlying_symbol_name||x.underlying_symbol,market:x.market||"Synthetic",submarket:x.submarket||""})).filter(x=>x.symbol);
    if(!state.markets.length){
      state.markets=items.filter(x=>/1HZ|R_[0-9]+|JD[0-9]+|stpRNG|BOOM|CRASH|STEP|跳/i.test(x.underlying_symbol||"")).map(x=>({symbol:x.underlying_symbol,name:x.underlying_symbol_name||x.underlying_symbol,market:"Synthetic",submarket:""}));
    }
    $("market-count").textContent=state.markets.length||"—"; renderMarkets();
    if(!state.selected && state.markets.length) selectMarket(state.markets[0].symbol);
  }
  function renderMarkets(){
    const q=$("market-search").value.toLowerCase();
    const list=state.markets.filter(m=>(m.name+" "+m.symbol).toLowerCase().includes(q));
    $("market-list").innerHTML=list.length?list.map(m=>`<button class="market-item ${state.selected===m.symbol?"active":""}" data-symbol="${escapeHtml(m.symbol)}"><span><b>${escapeHtml(m.name)}</b><small>${escapeHtml(m.symbol)}</small></span><span class="market-price" id="price-${safeId(m.symbol)}">—</span></button>`).join(""):'<div class="loading">No matching synthetic indices found.</div>';
    document.querySelectorAll(".market-item").forEach(btn=>btn.addEventListener("click",()=>selectMarket(btn.dataset.symbol)));
  }
  function selectMarket(symbol){
    if(!symbol)return;
    state.selected=symbol;state.ticks=[];state.candles=[];state.lastSignalKey="";
    const m=state.markets.find(x=>x.symbol===symbol);
    $("chart-market-name").textContent=m?m.name:symbol;$("selected-market-stat").textContent=symbol;
    $("current-price").textContent="—";$("market-price").textContent="Loading price…";
    $("chart-empty").style.display="grid";renderMarkets();resetSignals();
    send({ticks_history:symbol,count:500,end:"latest",style:"ticks",req_id:2});
    send({ticks:symbol,subscribe:1,req_id:3});
  }
  function handleHistory(msg){
    if(msg.echo_req && msg.echo_req.ticks_history!==state.selected)return;
    const prices=msg.history.prices||[],times=msg.history.times||[];
    state.ticks=prices.map((p,i)=>({price:Number(p),time:Number(times[i])})).filter(x=>Number.isFinite(x.price)&&Number.isFinite(x.time));
    rebuildCandles();updateDisplay();
  }
  function handleTick(tick){
    if(!tick||tick.symbol!==state.selected)return;
    const item={price:Number(tick.quote),time:Number(tick.epoch)};
    if(!Number.isFinite(item.price)||!Number.isFinite(item.time))return;
    const last=state.ticks[state.ticks.length-1];
    if(!last||item.time>=last.time)state.ticks.push(item);
    if(state.ticks.length>1200)state.ticks=state.ticks.slice(-1200);
    rebuildCandles();updateDisplay();
    const priceEl=$("price-"+safeId(state.selected));if(priceEl)priceEl.textContent=formatPrice(item.price);
  }
  function rebuildCandles(){
    const map=new Map();
    state.ticks.forEach(t=>{const bucket=Math.floor(t.time/state.candleSeconds)*state.candleSeconds;let c=map.get(bucket);if(!c){c={time:bucket,open:t.price,high:t.price,low:t.price,close:t.price};map.set(bucket,c);}else{c.high=Math.max(c.high,t.price);c.low=Math.min(c.low,t.price);c.close=t.price;}});
    state.candles=[...map.values()].sort((a,b)=>a.time-b.time).slice(-80);
  }
  function updateDisplay(){
    const last=state.ticks.at(-1);if(!last)return;
    $("chart-empty").style.display="none";$("current-price").textContent=formatPrice(last.price);$("market-price").textContent="Live · "+new Date(last.time*1000).toLocaleTimeString();
    const first=state.ticks[0];const change=first?((last.price-first.price)/first.price*100):0;
    $("price-change").textContent=(change>=0?"+":"")+change.toFixed(3)+"% since loaded";
    const closes=state.candles.map(c=>c.close),ema9=ema(closes,9),ema21=ema(closes,21),rsiVal=rsi(state.ticks.map(t=>t.price),14);
    $("ema-value").textContent=ema9?formatPrice(ema9):"—";$("ema21-value").textContent=ema21?formatPrice(ema21):"—";$("rsi-value").textContent=rsiVal===null?"—":rsiVal.toFixed(1);
    drawChart();analyse(last.price,ema9,ema21,rsiVal);
  }
  function analyse(price,e9,e21,rsiVal){
    const prices=state.ticks.map(t=>t.price);if(prices.length<35||!e9||!e21||rsiVal===null){resetSignals();return;}
    const trend=e9>e21?"RISE":e9<e21?"FALL":"WAIT";
    const momentum=prices.at(-1)-prices.at(-8);const agree=(trend==="RISE"&&momentum>0)||(trend==="FALL"&&momentum<0);
    const strength=Math.min(92,Math.max(50,Math.round(55+Math.abs(e9-e21)/Math.max(price,1)*100000+(agree?8:0))));
    const rf=trend==="WAIT"?"WAIT":(agree?trend:"WAIT");
    setSignal("rise-fall",rf,rf==="WAIT"?"Trend and short momentum do not agree.":`EMA 9 ${e9>e21?"above":"below"} EMA 21; short momentum ${momentum>0?"positive":"negative"}.`,rf==="WAIT"?0:strength);

    const digits=prices.slice(-100).map(lastDigit);const over=digits.filter(d=>d>=5).length/digits.length;const under=1-over;
    const ou=over>under?"OVER 4": "UNDER 5";const ouConf=Math.round(Math.max(over,under)*100);
    setSignal("over-under",Math.abs(over-under)<.08?"WAIT":ou,`Last ${digits.length} digits: ${Math.round(over*100)}% were 5–9.`,Math.abs(over-under)<.08?0:ouConf);

    const counts=Array(10).fill(0);digits.forEach(d=>counts[d]++);const maxDigit=counts.indexOf(Math.max(...counts));const matchConf=Math.round(counts[maxDigit]/digits.length*100);
    setSignal("match",matchConf>=16?`MATCH ${maxDigit}`:"WAIT",`Most frequent recent digit: ${maxDigit} (${counts[maxDigit]} of ${digits.length}).`,matchConf>=16?matchConf:0);

    const even=digits.filter(d=>d%2===0).length/digits.length;const eo=Math.abs(even-.5)<.08?"WAIT":(even>.5?"EVEN":"ODD");
    setSignal("even-odd",eo,`${Math.round(even*100)}% even digits in the latest ${digits.length} ticks.`,eo==="WAIT"?0:Math.round(Math.max(even,1-even)*100));
    const key=[state.selected,rf,ou,maxDigit,eo,Math.floor(lastTime()/60)].join("|");
    if(key!==state.lastSignalKey && (rf!=="WAIT"||eo!=="WAIT")){state.lastSignalKey=key;addHistory({time:new Date().toLocaleTimeString(),market:state.selected,type:"Market analysis",signal:[rf,ou,`MATCH ${maxDigit}`,eo].filter(x=>x!=="WAIT").join(" · "),confidence:Math.max(strength,ouConf,matchConf)});}
    $("latest-signal-stat").textContent=rf;$("latest-signal-time").textContent=rf==="WAIT"?"No clear trend": "Updated "+new Date().toLocaleTimeString();
  }
  function setSignal(prefix,value,detail,confidence){$(prefix+"-signal").textContent=value;$(prefix+"-detail").textContent=detail;$(prefix+"-bar").style.width=confidence+"%";$(prefix+"-confidence").textContent=confidence?`Sample strength: ${confidence}%`:"Confidence: not available";}
  function resetSignals(){setSignal("rise-fall","WAIT","Collecting enough ticks to analyse trend.",0);setSignal("over-under","WAIT","Digit analysis will appear when data arrives.",0);setSignal("match","WAIT","Last-digit distribution is being calculated.",0);setSignal("even-odd","WAIT","Waiting for a useful sample.",0);}
  function addHistory(row){state.history.unshift(row);state.history=state.history.slice(0,30);try{localStorage.setItem("dpa-history",JSON.stringify(state.history));}catch{}renderHistory();}
  function renderHistory(){ $("signal-count").textContent=state.history.length;$("history-body").innerHTML=state.history.length?state.history.map(r=>`<tr><td>${escapeHtml(r.time)}</td><td>${escapeHtml(r.market)}</td><td>${escapeHtml(r.type)}</td><td>${escapeHtml(r.signal)}</td><td>${r.confidence}%</td></tr>`).join(""):'<tr><td colspan="5" class="empty-row">Signals will appear here after analysis starts.</td></tr>'; }
  function drawChart(){
    const canvas=$("price-chart"),ctx=canvas.getContext("2d"),rect=canvas.getBoundingClientRect(),dpr=window.devicePixelRatio||1;
    canvas.width=Math.max(1,rect.width*dpr);canvas.height=Math.max(1,rect.height*dpr);ctx.scale(dpr,dpr);
    const w=rect.width,h=rect.height,c=state.candles.slice(-60);if(!c.length)return;
    const min=Math.min(...c.map(x=>x.low)),max=Math.max(...c.map(x=>x.high)),pad=(max-min)*.12||Math.abs(max)*.0001||1,lo=min-pad,hi=max+pad;
    const y=v=>h-18-(v-lo)/(hi-lo)*(h-36),step=w/c.length,cw=Math.max(2,step*.55);
    ctx.strokeStyle="#1b2e44";ctx.lineWidth=1;ctx.fillStyle="#7890aa";ctx.font="10px DM Sans";
    for(let i=0;i<5;i++){const yy=15+i*(h-30)/4;ctx.beginPath();ctx.moveTo(0,yy);ctx.lineTo(w,yy);ctx.stroke();}
    c.forEach((k,i)=>{const x=i*step+step/2,up=k.close>=k.open;ctx.strokeStyle=up?"#2ed6a0":"#ff6f83";ctx.fillStyle=ctx.strokeStyle;ctx.beginPath();ctx.moveTo(x,y(k.high));ctx.lineTo(x,y(k.low));ctx.stroke();const top=y(Math.max(k.open,k.close)),bottom=y(Math.min(k.open,k.close));ctx.fillRect(x-cw/2,top,cw,Math.max(1,bottom-top));});
  }
  function ema(values,period){if(values.length<period)return null;const k=2/(period+1);let out=values.slice(0,period).reduce((a,b)=>a+b,0)/period;for(let i=period;i<values.length;i++)out=values[i]*k+out*(1-k);return out;}
  function rsi(values,period){if(values.length<=period)return null;let gains=0,losses=0;for(let i=values.length-period;i<values.length;i++){const d=values[i]-values[i-1];if(d>0)gains+=d;else losses-=d;}if(losses===0)return 100;return 100-(100/(1+gains/losses));}
  function lastDigit(price){const s=String(price);const decimals=s.includes(".")?s.split(".")[1]:"";return Number((decimals||"0").slice(-1));}
  function formatPrice(n){return Number(n).toLocaleString(undefined,{maximumFractionDigits:8});}
  function lastTime(){return state.ticks.at(-1)?.time||Date.now()/1000;}
  function safeId(s){return String(s).replace(/[^a-z0-9]/gi,"_");}
  function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
  $("market-search").addEventListener("input",renderMarkets);
  $("candle-size").addEventListener("change",e=>{state.candleSeconds=Number(e.target.value);rebuildCandles();drawChart();});
  $("clear-history").addEventListener("click",()=>{state.history=[];localStorage.removeItem("dpa-history");renderHistory();});
  window.addEventListener("resize",drawChart);
  renderHistory();connect();
})();