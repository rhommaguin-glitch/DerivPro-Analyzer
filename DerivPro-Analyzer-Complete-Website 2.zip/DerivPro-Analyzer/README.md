# DerivPro Analyzer

A mobile-friendly, signals-only Deriv synthetic market dashboard.

## Included
- Live public Deriv synthetic market catalogue and tick feed
- Tick-derived candlestick chart (1m / 5m / 15m)
- EMA 9, EMA 21 and RSI 14 indicators
- Educational RISE/FALL, OVER/UNDER, MATCH/DIFFERS and EVEN/ODD analysis cards
- Signal history saved locally in the browser
- Responsive blue/dark interface for iPhone and desktop

## Important
This project uses Deriv's **public market-data WebSocket** only. It does not request a Deriv login, account token, balance, proposal, buy, sell or trade permissions. It cannot place trades.

Signals are simple statistical/technical estimates, not guaranteed predictions or financial advice. Historical digit frequency and indicator alignment do not establish future outcomes.

## Publish free with GitHub Pages
1. Upload `index.html`, `styles.css`, `app.js` and `README.md` to the root of your public GitHub repository.
2. Open the repository's **Settings**.
3. Open **Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site. GitHub will show the website address in the Pages section.

## Deriv data connection
The app connects to Deriv's public WebSocket endpoint:
`wss://api.derivws.com/trading/v1/options/ws/public`

It requests `active_symbols`, `ticks_history` and a live `ticks` subscription. These market-data requests do not require account authorization. If the API changes or your network blocks WebSockets, the status line will show a connection problem.

Official docs:
- https://developers.deriv.com/docs/data/active-symbols/
- https://developers.deriv.com/docs/data/ticks/
- https://developers.deriv.com/docs/data/ticks-history/

## Free hosting
GitHub Pages is free for public repositories. The app itself has no paid backend requirement.
