// DerivPro Analyzer — public market data only. No trading or account credentials.
const WS_URL = "wss://api.derivws.com/trading/v1/options/ws/public";
const $ = (id) => document.getElementById(id);
const state = {ws:null, symbols:[], candles:[], tickBuffer:[], history:[], symbol:"R_100", granularity:60, lastPrice:null, chart:null, candleSeries:null, reconnectTimer:null};

const chart = LightweightCharts.createChart($("chart"), {
  layout:{background:{type:"solid",color:"#091832"},textColor:"#9db2d2"},
  grid:{vertLines:{color:"#142b4d"},horzLines:{color:"#142b4d"}},
  rightPriceScale:{borderColor:"#24436b"},
  timeScale:{borderColor:"#24436b",timeVisible:true,secondsVisible:false},
  crosshair:{mode:LightweightCharts.CrosshairMode.Normal}
});
state.chart=chart;
state.candleSeries=chart.addCandlestickSeries({upColor:"#19d69a",downColor:"#ff5574",borderUpColor:"#19d69a",borderDownColor:"#ff5574",wickUpColor:"#19d69a",wickDownColor:"#ff5574"});
new ResizeObserver(()=>chart.applyOptions({width:$("chart").clientWidth})).observe($("chart"));

function setConnection(ok,label){$("connection").textContent=label;$("feedTag").textContent=ok?"LIVE STREAM":"WAITING FOR DATA";$("feedTag").style.color=ok?"#19d69a":"#93a8c8";}
function send(payload){if(state.ws && state.ws.readyState===WebSocket.OPEN)state.ws.send(JSON.stringify(payload));}
function connect(){
  clearTimeout(state.reconnectTimer);
  if(state.ws){try{state.ws.close()}catch(e){}}
  setConnection(false,"CONNECTING");
  const ws=new WebSocket(WS_URL);state.ws=ws;
  ws.onopen=()=>{setConnection(true,"CONNECTED");send({active_symbols:"brief",product_type:"basic",req_id:1});};
  ws.onmessage=(event)=>{let d;try{d=JSON.parse(event.data)}catch(e){return}
    if(d.error){console.warn("Deriv API:",d.error.message);setConnection(false,"API MESSAGE");return}
    if(d.msg_type==="active_symbols"){state.symbols=d.active_symbols||[];renderMarkets();subscribeMarket();}
    if(d.msg_type==="history"){loadHistory(d);}
    if(d.msg_type==="tick"){handleTick(d.tick);}
  };
  ws.onerror=()=>setConnection(false,"CONNECTION ERROR");
  ws.onclose=()=>{setConnection(false,"RECONNECTING");state.reconnectTimer=setTimeout(connect,4000)};
}
function subscribeMarket(){
  send({forget_all:"ticks"});
  send({ticks_history:state.symbol,adjust_start_time:1,count:180,end:"latest",granularity:Number(state.granularity),style:"candles",req_id:2});
  send({ticks:state.symbol,subscribe:1,req_id:3});
  const selected=state.symbols.find(s=>s.symbol===state.symbol);
  $("marketTitle").textContent=selected?.display_name||state.symbol;
}
function loadHistory(d){
  const candles=(d.candles||[]).map(c=>({time:Number(c.epoch),open:Number(c.open),high:Number(c.high),low:Number(c.low),close:Number(c.close)}));
  if(candles.length){state.candles=candles;state.candleSeries.setData(candles);chart.timeScale().fitContent();analyze();}
}
function handleTick(t){
  if(!t||t.symbol!==state.symbol)return;
  const epoch=Number(t.epoch),price=Number(t.quote),bucket=Math.floor(epoch/Number(state.granularity))*Number(state.granularity);
  if(!Number.isFinite(price))return;
  const prev=state.lastPrice;state.lastPrice=price;
  $("lastPrice").textContent=price.toFixed(3);
  $("priceChange").textContent=prev===null?"Live tick":`${price>=prev?"▲":"▼"} ${(price-prev).toFixed(3)}`;
  $("priceChange").style.color=prev===null?"#93a8c8":price>=prev?"#19d69a":"#ff5574";
  $("lastUpdate").textContent=new Date().toLocaleTimeString();
  let last=state.candles[state.candles.length-1];
  if(!last||last.time!==bucket){last={time:bucket,open:price,high:price,low:price,close:price};state.candles.push(last)}
  else{last.high=Math.max(last.high,price);last.low=Math.min(last.low,price);last.close=price}
  state.candleSeries.update(last);
  if(state.candles.length>300)state.candles=state.candles.slice(-300);
  analyze();
}
function ema(values,period){if(values.length<period)return null;const k=2/(period+1);let v=values.slice(0,period).reduce((a,b)=>a+b,0)/period;for(let i=period;i<values.length;i++)v=values[i]*k+v*(1-k);return v}
function rsi(values,period=14){if(values.length<=period)return null;let gain=0,loss=0;for(let i=values.length-period;i<values.length;i++){let d=values[i]-values[i-1];if(d>0)gain+=d;else loss-=d}if(loss===0)return 100;let rs=(gain/period)/(loss/period);return 100-100/(1+rs)}
function analyze(){
  const closes=state.candles.map(c=>c.close);if(closes.length<25)return;
  const r=rsi(closes),e9=ema(closes,9),e21=ema(closes,21),mom=closes.at(-1)-closes.at(-4);
  $("rsi").textContent=r===null?"—":r.toFixed(1);
  $("ema").textContent=e9&&e21?(e9>e21?"Bullish":"Bearish"):"—";
  $("momentum").textContent=mom>0?"Positive":mom<0?"Negative":"Flat";
  // Conservative illustrative rule: multiple indicators must align; otherwise WAIT.
  let bias="WAIT",note="Indicators are mixed";
  if(e9>e21 && mom>0 && r>=50 && r<70){bias="RISE";note="EMA trend and momentum align";}
  else if(e9<e21 && mom<0 && r<=50 && r>30){bias="FALL";note="EMA trend and momentum align";}
  const card=$("signalCard");card.className="signal "+(bias==="RISE"?"rise":bias==="FALL"?"fall":"neutral");
  $("signalArrow").textContent=bias==="RISE"?"↑":bias==="FALL"?"↓":"—";
  $("signalText").textContent=bias;$("signalNote").textContent=note;
  if(bias!=="WAIT"){const key=`${state.symbol}-${state.candles.at(-1).time}-${bias}`;if(!state.history.some(x=>x.key===key)){state.history.unshift({key,bias,symbol:state.symbol,time:new Date().toLocaleTimeString()});state.history=state.history.slice(0,20);renderHistory();}}
}
function renderMarkets(){
  const preferred=["R_100","R_75","R_50","R_25","R_10","1HZ100V","1HZ75V","1HZ50V","1HZ25V","1HZ10V","BOOM1000","CRASH1000","STEP","JD100"];
  const available=state.symbols.filter(s=>/volatility|boom|crash|step|jump|range break/i.test(s.display_name||""));
  available.sort((a,b)=>{let ai=preferred.indexOf(a.symbol),bi=preferred.indexOf(b.symbol);return (ai<0?999:ai)-(bi<0?999:bi)});
  $("marketCount").textContent=`${available.length} markets found`;
  $("marketList").innerHTML="";
  available.slice(0,24).forEach(s=>{const b=document.createElement("button");b.className="market-item"+(s.symbol===state.symbol?" active":"");b.innerHTML=`<b>${escapeHtml(s.display_name)}</b><span>${escapeHtml(s.symbol)}</span>`;b.onclick=()=>{state.symbol=s.symbol;state.candles=[];state.lastPrice=null;state.candleSeries.setData([]);document.querySelectorAll(".market-item").forEach(x=>x.classList.remove("active"));b.classList.add("active");subscribeMarket()};$("marketList").appendChild(b)});
}
function renderHistory(){
  $("history").innerHTML=state.history.length?state.history.map(x=>`<div class="history-row"><b>${escapeHtml(x.symbol)}</b><strong class="${x.bias==="RISE"?"rise-text":"fall-text"}">${x.bias}</strong><span>${x.time}</span></div>`).join(""):'<p class="muted">No signals yet. Waiting for aligned indicators.</p>';
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
$("timeframe").onchange=()=>{state.granularity=Number($("timeframe").value);state.candles=[];state.candleSeries.setData([]);subscribeMarket()};
$("refresh").onclick=connect;
$("clearHistory").onclick=()=>{state.history=[];renderHistory()};
connect();