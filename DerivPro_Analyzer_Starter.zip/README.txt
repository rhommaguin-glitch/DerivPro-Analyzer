# DerivPro Analyzer — free starter

This is a static website starter intended for phone-friendly editing and free static hosting.

## Included
- `index.html` — dashboard structure
- `styles.css` — responsive dark-blue design
- `app.js` — public Deriv WebSocket market feed, candlesticks, simple RSI/EMA/momentum bias, local signal history

## Important
- This is a prototype, not a profitable or validated prediction system.
- Signals are estimates, not guarantees or financial advice.
- It does not log into a Deriv account and does not place trades.
- Public API availability, symbol names, and WebSocket requirements can change. If the feed does not connect, check the current official Deriv API documentation.
- This prototype does not store history on a server; history is in the current page session only.

## How to publish free from an iPhone
1. Extract this ZIP in the iPhone Files app.
2. Create/sign in to a GitHub account in Safari.
3. Create a new public repository named `derivpro-analyzer`.
4. Upload `index.html`, `styles.css`, and `app.js` to the repository root (GitHub's website supports file uploads).
5. In repository Settings → Pages, choose deploy from the `main` branch and `/ (root)`.
6. Wait for GitHub Pages to publish, then open the provided URL on your iPhone.

You can also edit files using GitHub's web editor in Safari. Do not add your Deriv password or API token to these files.
